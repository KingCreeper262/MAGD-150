let timeManager = 0;
let circleX = 100;
let circleY = 150;
let circleRadius = 15
let circleXMove = 1;
let circleYMove = 1;
let canvasSize = 800;
let mouseTailX;
let mouseTailY;
let mouseSquareLength = 30;
function setup() {
  createCanvas(canvasSize, canvasSize); 
  frameRate(60)
}

function draw() { 
  background(110);
  mouseTail();
  manageSquare();
  manageCircle();
}

function manageCircle()
{
  fill(0, 0, 100);
  circle(circleX, circleY, circleRadius * 2);
  circleX += circleXMove;
  circleY += circleYMove;
  //This checks if the ball is colliding with the edge of tha canvas and flips its direction upon contact.
  if(dist(circleX, circleY, canvasSize, circleY) == circleRadius + 1)
  {
    circleXMove *= -1;
  }
  if(dist(circleX, circleY, 0, circleY) == circleRadius + 1)
  {
    circleXMove *= -1;
  }
  if(dist(circleX, circleY, circleX, canvasSize) == circleRadius + 1)
  {
    circleYMove *= -1;
  }
  if(dist(circleX, circleY, circleX, 0) == circleRadius + 1)
  {
    circleYMove *= -1;
  }
  
  //This checks if the square is hitting the circle
  if(mouseSquareLength / 2 + circleRadius >= 
     dist(mouseX + mouseSquareLength / 2, 
          mouseY + mouseSquareLength / 2, 
          circleX + circleRadius, 
          circleY + circleRadius))
  {
    let northCheck = abs(mouseY - mouseSquareLength / 2 - circleY);
    let southCheck = abs(mouseY + mouseSquareLength / 2 - circleY);
    let eastCheck = abs(mouseX - mouseSquareLength / 2 - circleX);
    let westCheck = abs(mouseX + mouseSquareLength / 2 - circleX);
    if(northCheck > circleRadius && northCheck > eastCheck && northCheck > westCheck)
    {
      circleYMove *= -1;
    }
    if(southCheck > circleRadius && southCheck > eastCheck && southCheck > westCheck)
    {
      circleYMove *= -1;
    }
    if(westCheck > circleRadius && westCheck > northCheck && westCheck > southCheck)
    {
      circleXMove *= -1;
    }
    if(eastCheck > circleRadius && eastCheck > northCheck && eastCheck > southCheck)
    {
      circleXMove *= -1;
    }
  }
}

function mouseTail()
{
  mouseTailX = pmouseX;
  mouseTailY = pmouseY;
  strokeWeight(30)
  stroke(200, 100, 0);
  line(mouseX, mouseY, mouseTailX, mouseTailY);
  strokeWeight(1);
  stroke(0);
}

function manageSquare()
{
  fill(200, 0, 0);
  square(mouseX - mouseSquareLength / 2, mouseY  - mouseSquareLength / 2, mouseSquareLength);
}