let canvasX = Math.random() * 400 + 400;
let canvasY = Math.random() * 400 + 400;

function setup() {
  createCanvas(canvasX, canvasY);
  c1 = new betterCircle(20, Math.random() * canvasX, Math.random() * canvasY, 3, 3);
  c2 = new betterCircle(10, Math.random() * canvasX, Math.random() * canvasY, 5, -5);
  c3 = new betterCircle(50, Math.random() * canvasX, Math.random() * canvasY, -1, 1)
  c4 = new betterCircle(5, Math.random() * canvasX, Math.random() * canvasY, -20, -20);
}

function draw() {
  background(220);
  c1.manageCirclePos();
  c2.manageCirclePos();
  c3.manageCirclePos();
  c4.manageCirclePos();
}

class betterCircle
{
  constructor(circleRadius, circleX, circleY, circleXMove, circleYMove)
  {
    this.circleRadius = circleRadius;
    this.circleXMove = circleXMove;
    this.circleYMove = circleYMove;
    this.circleX = circleX;
    this.circleY = circleY;
  }
  reset()
  {
    let num = Math.random();
    if(num < .5)
    {
      this.circleXMove *= -1;
    }
    num = Math.random();
    if(num < .5)
    {
      this.circleYMove *= -1;
    }
    
    this.circleX = Math.random() * canvasX;
    this.circleY = Math.random() * canvasY;
  }
  
  manageCirclePos()
  {
    circle(this.circleX, this.circleY, this.circleRadius);
    if(this.circleX + this.circleRadius < 0 || this.circleX - this.circleRadius > canvasX || this.circleY + this.circleRadius < 0 || this.circleY - this.circleRadius > canvasY)
    {
      this.reset();
    }
    else
    {
      this.circleX += this.circleXMove;
      this.circleY += this.circleYMove;
    }
  }  
}