let triangleX = 0;
let triangleY = 0;
let mouseCount = 0;
let keyCount = 0;

class BetterColor
{
  constructor(red, green, blue)
  {
    this.red = red;
    this.green = green;
    this.blue = blue;
  }
}

let colors = [new BetterColor(255, 0 ,0), new BetterColor(0, 255, 0), new BetterColor(0, 0, 255), new BetterColor(100, 97, 200), new BetterColor(150, 29, 120)]
let triangleColor = 0;

function setup() {
  createCanvas(400, 400);
  triangeX = mouseX;
  triangleY = mouseY;
}

function draw() {
  background(colors[keyCount].red, colors[keyCount].green, colors[keyCount].blue);
  mouseManager();
  
}
function mouseManager()
{
  triangleX += movedX;
  triangleY += movedY;
  mouseX += movedX;
  mouseY += movedY;
  fill(colors[triangleColor].red, 
       colors[triangleColor].green, 
       colors[triangleColor].blue);
  triangle(triangleX, triangleY, 
           triangleX+10, triangleY+10, 
           triangleX, triangleY+10);
}
function mousePressed()
{
  if(mouseCount == 0)
  {
    mouseCount++;
    requestPointerLock();
  }
  if(triangleColor == colors.length - 1)
    {
      triangleColor = 0;
    }
    else
    {
      triangleColor++;
    }
}
function keyPressed()
{
  let nums = [0, 0 ,0];
  for(i = 0; i < 3; i++)
  {
    nums[i] = (int) (Math.random() * 255);
  }
  colors[keyCount] = new BetterColor(nums[0], nums[1], nums[2]);
  if(keyCount == colors.length - 1)
  {
    keyCount = 0;
  }
  else
  {
    keyCount++;
  }
}